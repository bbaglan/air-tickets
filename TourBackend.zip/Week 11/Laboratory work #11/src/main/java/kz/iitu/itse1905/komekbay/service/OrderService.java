package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Order;
import kz.iitu.itse1905.komekbay.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class OrderService {
    private OrderRepository orderRepository;

    @Autowired
    public void setOrderRepository(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }


    @Transactional(readOnly = true)
    public List<Order> getAll(){
        return orderRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Order saveOrder(Order order){
        return orderRepository.save(order);
    }
}
