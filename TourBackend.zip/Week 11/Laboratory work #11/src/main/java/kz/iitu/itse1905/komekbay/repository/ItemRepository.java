package kz.iitu.itse1905.komekbay.repository;

import kz.iitu.itse1905.komekbay.database.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ItemRepository extends JpaRepository<Item,Integer>{

    List<Item> findAll();
    Item save(Item item);
    void deleteById(int id);
    List<Item> findByCostAndItemResidue(float cost, int itemResid);
}
