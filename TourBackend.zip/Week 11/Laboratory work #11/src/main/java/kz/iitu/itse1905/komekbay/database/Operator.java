package kz.iitu.itse1905.komekbay.database;

import lombok.AllArgsConstructor;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;


@AllArgsConstructor
@Entity
@Table(name = "operator")
public class Operator {
    private int id;
    private String login;
    private String password;

    public Operator() {

    }


    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column
    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    @Column
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Id: " + id + "; Login: " + login + "; password: " + password;
    }
}
