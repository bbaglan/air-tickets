package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.User;
import kz.iitu.itse1905.komekbay.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class UserService {

    private UserRepository userRepository;

    @Autowired
    public void setUserRepository(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Cacheable(cacheNames = "getAllCacheUser")
    public List<User> getAll(){
        return userRepository.findAll();
    }

    @Transactional(readOnly = true)
    public User saveUser(User user){
        return userRepository.save(user);
    }

    @Transactional(readOnly = true)
    public void deleteUserById(int id){
        userRepository.deleteById(id);
    }



    @Cacheable(cacheNames = "getByIdGreaterThan")
    public List<User> getByIdGreaterThan(int id){
        return userRepository.findByIdGreaterThan(id);
    }

    @Cacheable(cacheNames = "getByIdLessThan")
    public List<User> getByIdLessThan(int id){
        return userRepository.findByIdLessThan(id);
    }

    public User findUserByID(int id){
        return userRepository.findUserById(id);
    }

}