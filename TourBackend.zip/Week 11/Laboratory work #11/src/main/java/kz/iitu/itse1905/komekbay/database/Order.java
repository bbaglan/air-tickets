package kz.iitu.itse1905.komekbay.database;

import lombok.AllArgsConstructor;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;

@AllArgsConstructor
@Entity(name = "orders")
@Table(name = "orders")
public class Order {
    private int id;
    private int whoOrderedId;
    private boolean accepted;
    private int orderedItemId;

    public Order() {
    }

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getWhoOrderedId() {
        return whoOrderedId;
    }

    public void setWhoOrderedId(int whoOrderedId) {
        this.whoOrderedId = whoOrderedId;
    }

    public boolean isAccepted() {
        return accepted;
    }

    public void setAccepted(boolean accepted) {
        this.accepted = accepted;
    }

    public int getOrderedItemId() {
        return orderedItemId;
    }

    public void setOrderedItemId(int orderedItemId) {
        this.orderedItemId = orderedItemId;
    }

    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", whoOrderedId=" + whoOrderedId +
                ", accepted=" + accepted +
                ", orderedItemId=" + orderedItemId +
                '}';
    }
}
