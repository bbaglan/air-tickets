package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.User;
import kz.iitu.itse1905.komekbay.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private UserService userService;


    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @ExceptionHandler
    @GetMapping(path = "/")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResponseEntity<List<User>> getAllUser(){
        List<User> users = userService.getAll();
        return ResponseEntity.ok(users);
    }

    @ExceptionHandler
    @PostMapping(path = "/",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public ResponseEntity<User> create(@RequestBody User newUser) {

        User user = userService.saveUser(newUser);
        return new ResponseEntity<>(user, HttpStatus.CREATED);
    }

    @ExceptionHandler
    @PutMapping(value="{id}")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public void update(@RequestBody User user,
                       @PathVariable int id) {
        userService.saveUser(user);
    }

    @ExceptionHandler
    @DeleteMapping(value = "/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public ResponseEntity<Void> deleteUserById(@PathVariable(value = "id") int id){
        userService.deleteUserById(id);
        return ResponseEntity.ok().build();
    }
}
