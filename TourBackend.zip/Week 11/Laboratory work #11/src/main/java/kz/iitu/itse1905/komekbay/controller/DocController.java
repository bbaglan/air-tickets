package kz.iitu.itse1905.komekbay.controller;

import com.google.common.net.HttpHeaders;
import kz.iitu.itse1905.komekbay.database.Doc;
import kz.iitu.itse1905.komekbay.service.DocStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/doc")
public class DocController {
    private DocStorageService docStorageService;

    @Autowired
    public DocController(DocStorageService docStorageService) {
        this.docStorageService = docStorageService;
    }

    @GetMapping("/")
    public List<Doc> get(Model model){
        List<Doc> docs = docStorageService.getFiles();
        return docs;
    }

    @PostMapping("/upload")
    public String uploadMultipleFiles(@RequestParam("files") MultipartFile[] files){
        for (MultipartFile file: files){
            docStorageService.saveFile(file);
        }
        return "Uploaded";
    }

    @GetMapping("/download/{fileId}")
    public ResponseEntity<ByteArrayResource> downloadFile(@PathVariable Integer fileId){
        Doc doc = docStorageService.getFile(fileId).get();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(doc.getDocType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment:filename=/" + doc.getDocName()+"\"")
                .body(new ByteArrayResource(doc.getData()));
    }
}
