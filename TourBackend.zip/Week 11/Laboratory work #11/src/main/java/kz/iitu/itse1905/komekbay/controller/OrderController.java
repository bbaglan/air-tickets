package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Order;
import kz.iitu.itse1905.komekbay.jms.MessageSender;
import kz.iitu.itse1905.komekbay.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/order")
public class OrderController {

    private OrderService orderService;
    private MessageSender messageSender;

    @Autowired
    public OrderController(OrderService orderService, MessageSender messageSender) {
        this.orderService = orderService;
        this.messageSender = messageSender;
    }

    @ExceptionHandler
    @GetMapping(path = "/")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResponseEntity<List<Order>> getAllOrder(){
        List<Order> orders = orderService.getAll();
        return ResponseEntity.ok(orders);
    }


    @ExceptionHandler
    @PostMapping(path = "/",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public ResponseEntity<String> sendOrder(@RequestBody Order newOrder) {
        newOrder.setAccepted(false);
        String string = messageSender.sendMessage(newOrder);
        return new ResponseEntity<>(string, HttpStatus.CREATED);
    }

    Order order;
    @JmsListener(destination = "queue", containerFactory = "myFactory")
    public void receiveMessage(Order order) {
        orderService.saveOrder(order);
    }

    @ExceptionHandler
    @PostMapping(path = "/checkOrder")
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public ResponseEntity<Order> acceptAndCreateOrder(){
        if (order != null) {
            order.setAccepted(true);
        }
        Order order1 = orderService.saveOrder(order);
        return new ResponseEntity<>(order1, HttpStatus.CREATED);
    }
}
