package kz.iitu.itse1905.komekbay.database;


import lombok.AllArgsConstructor;

import javax.persistence.*;

import static javax.persistence.GenerationType.IDENTITY;


@AllArgsConstructor
@Entity
@Table(name = "ITEM")
public class Item {

    private int id;
    private String name;
    private float cost;
    private int itemResidue;

    public Item() {

    }

    @Id
    @GeneratedValue(strategy = IDENTITY)
    @Column(name = "id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name = "cost")
    public float getCost() {
        return cost;
    }

    public void setCost(float cost) {
        this.cost = cost;
    }

    @Column(name = "item_residue")
    public int getItemResidue() {
        return itemResidue;
    }

    public void setItemResidue(int itemResidue) {
        this.itemResidue = itemResidue;
    }

    @Override
    public String toString() {
        return "Id: " + id + "; Name: " + name + "; cost: " + cost + "; itemResidue: " + itemResidue;
    }
}
