package kz.iitu.itse1905.komekbay.repository;

import kz.iitu.itse1905.komekbay.database.Operator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OperatorRepository extends JpaRepository<Operator, Integer> {

    @Query("select o from Operator o")
    public List<Operator> findAll();
    Operator save(Operator operator);
    void deleteById(int id);
    Operator findByLoginLike(String login);
    List<Operator> findByLoginNotLike(String login);
}
