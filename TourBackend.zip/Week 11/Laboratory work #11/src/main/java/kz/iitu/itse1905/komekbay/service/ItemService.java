package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Item;
import kz.iitu.itse1905.komekbay.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ItemService {

    private ItemRepository itemRepository;


    @Autowired
    public void setItemRepository(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }


    @Cacheable(cacheNames = "getAllCacheItem")
    @Transactional(readOnly = true)
    public List<Item> getAll(){
        return itemRepository.findAll();
    }

    @Cacheable(cacheNames = "getItemByIdCache")
    @Transactional(propagation = Propagation.NEVER)
    public void deleteItemById(int id){
        itemRepository.deleteById(id);
    }


    @Transactional(readOnly = true)
    public Item saveItem(Item item){
        return itemRepository.save(item);
    }

    @Transactional(readOnly = true)
    public List<Item> getAllWithPaging(int pageNO, int pageSize){
        Page<Item> pagedResult = itemRepository.findAll(PageRequest.of(pageNO,pageSize));
        return pagedResult.toList();
    }

    @Cacheable(cacheNames = "getByCostAndItemResidueCache")
    @Transactional(isolation = Isolation.DEFAULT)
    public List<Item> getByCostAndItemResidue(float cost, int itemResid){
        return itemRepository.findByCostAndItemResidue(cost, itemResid);
    }
}
