package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Operator;
import kz.iitu.itse1905.komekbay.service.OperatorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/operator")
public class OperatorController {
    private OperatorService operatorService;


    @Autowired
    public OperatorController(OperatorService operatorService) {
        this.operatorService = operatorService;
    }

    @ExceptionHandler
    @GetMapping(path = "/")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResponseEntity<List<Operator>> getAllOperator(){
        List<Operator> operators = operatorService.getAll();
        return ResponseEntity.ok().body(operators);
    }

    @ExceptionHandler
    @PostMapping(path = "/",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public ResponseEntity<Operator> create(@RequestBody Operator newOper) {

        Operator operator = operatorService.saveOper(newOper);
        return new ResponseEntity<>(operator, HttpStatus.CREATED);
    }

    @ExceptionHandler
    @PutMapping(value="{id}")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public void update(@RequestBody Operator operator,
                       @PathVariable int id) {
        operatorService.saveOper(operator);
    }

    @ExceptionHandler
    @DeleteMapping(value = "/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public ResponseEntity<Void> deleteOperatorById(@PathVariable(value = "id") int id){
        operatorService.deleteOperatorById(id);
        return ResponseEntity.ok().build();
    }
}
