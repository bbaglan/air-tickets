package kz.iitu.itse1905.komekbay.repository;

import kz.iitu.itse1905.komekbay.database.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

    @Query("select u from #{#entityName} u")
    List<User> findAll();
    User save(User user);
    void deleteById(int id);
    List<User> findByIdGreaterThan(int id);
    List<User> findByIdLessThan(int id);
    User findUserById(int id);
}
