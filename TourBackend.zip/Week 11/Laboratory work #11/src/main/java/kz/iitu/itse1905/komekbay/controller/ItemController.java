package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Item;
import kz.iitu.itse1905.komekbay.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tours")
public class ItemController {

    private ItemService itemService;


    @Autowired
    public ItemController(ItemService itemService) {
        this.itemService = itemService;
    }

    @ExceptionHandler
    @RequestMapping(value = "/headitem",method = RequestMethod.HEAD,produces = "application/json")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<List<Item>> findHeadItem() {
        List<Item> item = itemService.getAll();
        return ResponseEntity.ok(item);

    }

    @ExceptionHandler
    @RequestMapping(value="/optionitem", method = RequestMethod.OPTIONS)
    ResponseEntity<?> collectionOptionsItem()
    {
        return ResponseEntity
                .ok()
                .allow(HttpMethod.GET,HttpMethod.HEAD, HttpMethod.OPTIONS)
                .build();
    }

    @ExceptionHandler
    @GetMapping(path = "/")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResponseEntity<List<Item>> getAllItem(){
        List<Item> items = itemService.getAll();
        return ResponseEntity.ok(items);
    }

    @ExceptionHandler
    @GetMapping(path = "/paging/{pageNO}/{pageSize}")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public ResponseEntity<List<Item>> getAllItemWithPaging(
            @PathVariable int pageNO,
            @PathVariable int pageSize
    ){
        List<Item> items = itemService.getAllWithPaging(pageNO,pageSize);
        return ResponseEntity.ok(items);
    }

    @ExceptionHandler
    @PostMapping(path = "/",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    public ResponseEntity<Item> create(@RequestBody Item newItem) {

            Item item = itemService.saveItem(newItem);
            return new ResponseEntity<>(item, HttpStatus.CREATED);
    }

    @ExceptionHandler
    @PutMapping(value="{id}")
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    public void update(@RequestBody Item item,
                       @PathVariable int id) {
        itemService.saveItem(item);
    }

    @ExceptionHandler
    @DeleteMapping(value = "/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public ResponseEntity<Void> deleteItemById(@PathVariable(value = "id") int id){
            itemService.deleteItemById(id);
            return ResponseEntity.ok().build();
    }
}