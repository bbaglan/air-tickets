package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Operator;
import kz.iitu.itse1905.komekbay.repository.OperatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
public class OperatorService {

    private OperatorRepository operatorRepository;

    @Autowired
    public void setOperatorRepository(OperatorRepository operatorRepository) {
        this.operatorRepository = operatorRepository;
    }


    @Cacheable(cacheNames = "getAllCacheOper")
    public List<Operator> getAll(){
        return operatorRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Operator saveOper(Operator operator){
        return operatorRepository.save(operator);
    }

    @Transactional(readOnly = true)
    public void deleteOperatorById(int id){
        operatorRepository.deleteById(id);
    }

    @Cacheable(cacheNames = "getByLoginLike")
    @Transactional(timeout = 10)
    public Operator getByLoginLike(String login){
        return operatorRepository.findByLoginLike(login);
    }

    @Cacheable(cacheNames = "getByLoginNotLike")
    @Transactional(rollbackFor = {RuntimeException.class})
    public List<Operator> getByLoginNotLike(String login){
        return operatorRepository.findByLoginNotLike(login);
    }

}
