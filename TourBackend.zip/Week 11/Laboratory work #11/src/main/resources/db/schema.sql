
CREATE TABLE ITEM (
                      ID INT NOT NULL AUTO_INCREMENT
    , NAME VARCHAR(60) NOT NULL
    , COST float NOT NULL
    , ITEM_RESIDUE integer
    ,PRIMARY KEY (ID)
);


CREATE TABLE OPERATOR (
                          ID INT NOT NULL AUTO_INCREMENT
    , LOGIN VARCHAR(60) NOT NULL
    , PASSWORD VARCHAR(60) NOT NULL
    ,PRIMARY KEY (ID)
);


CREATE TABLE USERS (
                       ID INT NOT NULL AUTO_INCREMENT
    , USERNAME VARCHAR(60) NOT NULL
    , PASSWORD VARCHAR(60) NOT NULL
    , PHONE_NUMBER VARCHAR(60) NOT NULL
    ,PRIMARY KEY (ID)
);

CREATE TABLE DOC (
                       ID INT NOT NULL AUTO_INCREMENT
    , docName VARCHAR(60) NOT NULL
    , docType VARCHAR(60) NOT NULL
    , data binary NOT NULL
    ,PRIMARY KEY (ID)
);

CREATE TABLE ORDERS (
                     ID INT NOT NULL AUTO_INCREMENT
    , whoOrderedId INT NOT NULL
    , accepted boolean NOT NULL
    , orderedItemId INT NOT NULL
    ,PRIMARY KEY (ID)
);