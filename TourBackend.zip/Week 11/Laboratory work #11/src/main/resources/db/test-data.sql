
insert into item (name, cost, item_residue) values ('Tour1', 200, 5);
insert into item (name, cost, item_residue) values ('Tour2', 200, 5);
insert into item (name, cost, item_residue) values ('Tour3', 200, 5);
insert into item (name, cost, item_residue) values ('Tour4', 200, 5);
insert into item (name, cost, item_residue) values ('Tour5', 200, 5);
insert into item (name, cost, item_residue) values ('Tour6', 200, 5);
insert into item (name, cost, item_residue) values ('Tour7', 200, 5);


insert into doc (docName, docType, data) values ('Johnss', 'text/plain', 01410101);

insert into orders (whoOrderedId, accepted, orderedItemId) values (2, false, 1);

insert into operator (login, password) values ('JohnssOper', 'oper1');

insert into users (username, password, phone_number) values ('User1', 'pass1', '87026232102');
insert into users (username, password, phone_number) values ('User2', 'pass2', '87021327777');
