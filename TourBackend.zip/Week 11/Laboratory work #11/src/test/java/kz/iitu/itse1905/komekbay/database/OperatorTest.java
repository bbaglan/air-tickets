package kz.iitu.itse1905.komekbay.database;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class OperatorTest {
    Operator operator = new Operator(0, "login", "password");
    Operator operator1 = new Operator();

    @Test
    public void testGetID() {
        ReflectionTestUtils.setField(operator1, "id", 1);

        Assertions.assertEquals(operator1.getId(), 1);
        operator1.setId(2);
        Assertions.assertEquals(operator1.getId(), 2);
    }
    @Test
    public void testGetLogin() {
        ReflectionTestUtils.setField(operator1, "login", "someLogin");

        Assertions.assertEquals(operator1.getLogin(), "someLogin");
        operator1.setLogin("someLogin2");
        Assertions.assertEquals(operator1.getLogin(), "someLogin2");
    }
    @Test
    public void testGetPassword() {
        ReflectionTestUtils.setField(operator1, "password", "somePass");

        Assertions.assertEquals(operator1.getPassword(), "somePass");
        operator1.setPassword("somePass2");
        Assertions.assertEquals(operator1.getPassword(), "somePass2");
    }

    @Test
    public void testToString() {
        ReflectionTestUtils.setField(operator1, "id", 1);
        ReflectionTestUtils.setField(operator1, "login", "someLogin");
        ReflectionTestUtils.setField(operator1, "password", "somePass");

        Assertions.assertEquals(ReflectionTestUtils.invokeMethod(operator1, "toString"), "Id: 1; Login: someLogin; password: somePass");
    }
}

