package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Order;
import kz.iitu.itse1905.komekbay.jms.MessageSender;
import kz.iitu.itse1905.komekbay.service.OrderService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class OrderControllerTest {
    @Mock
    OrderService orderService;
    @Mock
    MessageSender messageSender;
    @Mock
    Order order;
    @InjectMocks
    OrderController orderController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAllOrder() {
        when(orderService.getAll()).thenReturn(Arrays.<Order>asList(new Order(0, 0, true, 0)));

        ResponseEntity<List<Order>> result = orderController.getAllOrder();
        Assertions.assertNotNull(result);
    }

    @Test
    void testSendOrder() {
        when(messageSender.sendMessage(any())).thenReturn("sendMessageResponse");

        ResponseEntity<String> result = orderController.sendOrder(new Order(0, 0, true, 0));
        Assertions.assertNotNull(result);
    }

    @Test
    void testReceiveMessage() {
        orderController.receiveMessage(new Order(0, 0, true, 0));
    }

    @Test
    void testAcceptAndCreateOrder() {
        when(orderService.saveOrder(any())).thenReturn(new Order(0, 0, true, 0));

        ResponseEntity<Order> result = orderController.acceptAndCreateOrder();
        Assertions.assertTrue(true);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme