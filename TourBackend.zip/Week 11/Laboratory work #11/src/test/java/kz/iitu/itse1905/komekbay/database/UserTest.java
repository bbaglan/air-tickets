package kz.iitu.itse1905.komekbay.database;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class UserTest {
    User user = new User(0, "username", "password", "phoneNumber");
    User user1 = new User();
    @Test
    public void testGetID() {
        ReflectionTestUtils.setField(user1, "id", 1);

        Assertions.assertEquals(user1.getId(), 1);
        user1.setId(2);
        Assertions.assertEquals(user1.getId(), 2);
    }
    @Test
    public void testGetUsername() {
        ReflectionTestUtils.setField(user1, "username", "someUsername");

        Assertions.assertEquals(user1.getUsername(), "someUsername");
        user1.setUsername("someUsername2");
        Assertions.assertEquals(user1.getUsername(), "someUsername2");

    }
    @Test
    public void testGetPassword() {
        ReflectionTestUtils.setField(user1, "password", "somePass");

        Assertions.assertEquals(user1.getPassword(), "somePass");
        user1.setPassword("somePass2");
        Assertions.assertEquals(user1.getPassword(), "somePass2");
    }
    @Test
    public void testGetPhoneNumber() {
        ReflectionTestUtils.setField(user1, "phoneNumber", "someNumber");

        Assertions.assertEquals(user1.getPhoneNumber(), "someNumber");
        user1.setPhoneNumber("someNumber2");
        Assertions.assertEquals(user1.getPhoneNumber(), "someNumber2");

    }
    @Test
    public void testToString() {
        ReflectionTestUtils.setField(user1, "id", 1);
        ReflectionTestUtils.setField(user1, "username", "someUsername");
        ReflectionTestUtils.setField(user1, "password", "somePass");
        ReflectionTestUtils.setField(user1, "phoneNumber", "somePhone");

        Assertions.assertEquals(ReflectionTestUtils.invokeMethod(user1, "toString"), "Id: 1; Username: someUsername; password: somePass; phone:somePhone");
    }
}

