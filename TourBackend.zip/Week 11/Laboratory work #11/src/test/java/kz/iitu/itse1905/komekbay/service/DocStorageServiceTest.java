package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Doc;
import kz.iitu.itse1905.komekbay.repository.DocRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.List;
import java.util.Optional;

class DocStorageServiceTest {
    @Mock
    DocRepository docRepository;
    @InjectMocks
    DocStorageService docStorageService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSaveFile() {

    }

    @Test
    void testGetFile() {
        Optional<Doc> result = docStorageService.getFile(Integer.valueOf(0));
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetFiles() {
        List<Doc> result = docStorageService.getFiles();
        Assertions.assertNotNull(result);
    }
}