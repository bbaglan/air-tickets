package kz.iitu.itse1905.komekbay.database;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class OrderTest {
    Order order = new Order(0, 0, true, 0);
    Order order1 = new Order();

    @Test
    public void testGetID() {
        ReflectionTestUtils.setField(order1, "id", 1);
        Assertions.assertEquals(order1.getId(), 1);
        order1.setId(2);
        Assertions.assertEquals(order1.getId(), 2);
    }

    @Test
    public void testWhoOrdered() {
        ReflectionTestUtils.setField(order1, "whoOrderedId", 1);
        Assertions.assertEquals(order1.getWhoOrderedId(), 1);
        order1.setWhoOrderedId(2);
        Assertions.assertEquals(order1.getWhoOrderedId(), 2);
    }

    @Test
    public void testIsAccepted() {
        ReflectionTestUtils.setField(order1, "accepted", true);
        Assertions.assertTrue(order1.isAccepted());
        order1.setAccepted(false);
        Assertions.assertFalse(order1.isAccepted());
    }

    @Test
    public void testOrderedItemId() {
        ReflectionTestUtils.setField(order1, "orderedItemId", 1);
        Assertions.assertEquals(order1.getOrderedItemId(), 1);
        order1.setOrderedItemId(2);
        Assertions.assertEquals(order1.getOrderedItemId(), 2);
    }


    @Test
    void testToString() {
        String result = order.toString();
        Assertions.assertEquals(order.toString(), result,toString());
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme