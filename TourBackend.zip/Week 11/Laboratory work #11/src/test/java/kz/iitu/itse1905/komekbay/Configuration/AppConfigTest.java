package kz.iitu.itse1905.komekbay.Configuration;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

class AppConfigTest {
    @Mock
    Logger logger;
    @InjectMocks
    AppConfig appConfig;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testDataSource() {
        DataSource result = appConfig.dataSource();
        Assertions.assertEquals(null, result);
    }

    @Test
    void testTransactionManager() {
        PlatformTransactionManager result = appConfig.transactionManager();
        Assertions.assertNotNull(result);
    }

    @Test
    void testJpaVendorAdapter() {
        JpaVendorAdapter result = appConfig.jpaVendorAdapter();
        Assertions.assertNotNull(result);
    }

    @Test
    void testEntityManagerFactory() {
        EntityManagerFactory result = appConfig.entityManagerFactory();
        Assertions.assertNotNull(result);
    }
}