package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.User;
import kz.iitu.itse1905.komekbay.service.UserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class UserControllerTest {
    @Mock
    UserService userService;
    @InjectMocks
    UserController userController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAllUser() {
        when(userService.getAll()).thenReturn(Arrays.<User>asList(new User(0, "username", "password", "phoneNumber")));

        ResponseEntity<List<User>> result = userController.getAllUser();
        Assertions.assertNotNull(result);
    }

    @Test
    void testCreate() {
        when(userService.saveUser(any())).thenReturn(new User(0, "username", "password", "phoneNumber"));

        ResponseEntity<User> result = userController.create(new User(0, "username", "password", "phoneNumber"));
        Assertions.assertNotNull(result);
    }

    @Test
    void testUpdate() {
        when(userService.saveUser(any())).thenReturn(new User(0, "username", "password", "phoneNumber"));

        userController.update(new User(0, "username", "password", "phoneNumber"), 0);
    }

    @Test
    void testDeleteUserById() {


        String expect = ResponseEntity.ok().build().toString();

        ResponseEntity<Void> result = userController.deleteUserById(0);
        Assertions.assertNotNull(result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme