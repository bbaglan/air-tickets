package kz.iitu.itse1905.komekbay.jms;

import kz.iitu.itse1905.komekbay.database.Order;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jms.core.JmsTemplate;

class MessageSenderTest {
    @Mock
    JmsTemplate jmsTemplate;
    @InjectMocks
    MessageSender messageSender;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testSendMessage() {
        String result = messageSender.sendMessage(new Order(0, 0, true, 0));
        Assertions.assertEquals("Message has been sent", result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme