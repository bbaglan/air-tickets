package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Doc;
import kz.iitu.itse1905.komekbay.service.DocStorageService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.web.multipart.MultipartFile;

import java.util.Collections;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class DocControllerTest {
    @Mock
    DocStorageService docStorageService;
    @InjectMocks
    DocController docController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGet() {
        List<Doc> docs = Collections.singletonList(new Doc("docName", "docType", new byte[]{(byte) 0}));

        when(docStorageService.getFiles()).thenReturn(docs);

        List<Doc> result = docController.get(null);
        Assertions.assertEquals(docs, result);
    }

    @Test
    void testUploadMultipleFiles() {
        when(docStorageService.saveFile(any())).thenReturn(new Doc("docName", "docType", new byte[]{(byte) 0}));

        String result = docController.uploadMultipleFiles(new MultipartFile[]{null});
        Assertions.assertEquals("Uploaded", result);
    }

    @Test
    void testDownloadFile() {

    }
}