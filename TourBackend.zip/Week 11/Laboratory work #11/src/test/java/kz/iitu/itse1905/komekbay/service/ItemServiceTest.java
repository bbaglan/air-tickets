package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Item;
import kz.iitu.itse1905.komekbay.repository.ItemRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

class ItemServiceTest {
    @Mock
    ItemRepository itemRepository;
    @InjectMocks
    ItemService itemService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAll() {
        when(itemRepository.findAll()).thenReturn(Arrays.<Item>asList(new Item(0, "name", 0f, 0)));

        List<Item> result = itemService.getAll();
        Assertions.assertNotNull(result);
    }

    @Test
    void testDeleteItemById() {
        itemService.deleteItemById(0);
    }

    @Test
    void testSaveItem() {
        when(itemRepository.save(any())).thenReturn(new Item(0, "name", 0f, 0));

        Item result = itemService.saveItem(new Item(0, "name", 0f, 0));
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetAllWithPaging() {

    }

    @Test
    void testGetByCostAndItemResidue() {
        when(itemRepository.findByCostAndItemResidue(anyFloat(), anyInt())).thenReturn(Arrays.<Item>asList(new Item(0, "name", 0f, 0)));

        List<Item> result = itemService.getByCostAndItemResidue(0f, 0);
        Assertions.assertNotNull(result);
    }
}