package kz.iitu.itse1905.komekbay.Configuration;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.cache.CacheManager;

class CacheConfigTest {
    CacheConfig cacheConfig = new CacheConfig();

    @Test
    void testCacheManager() {
        CacheManager result = cacheConfig.cacheManager();
        Assertions.assertNotNull(result);
    }
}

