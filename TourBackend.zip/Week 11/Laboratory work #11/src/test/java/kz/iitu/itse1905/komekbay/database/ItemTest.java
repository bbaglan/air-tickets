package kz.iitu.itse1905.komekbay.database;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class ItemTest {
    Item item = new Item(0, "name", 0f, 0);
    Item item1 = new Item();
    @Test
    public void testGetID() {
        ReflectionTestUtils.setField(item1, "id", 1);
        Assertions.assertEquals(item1.getId(), 1);
        item1.setId(2);
        Assertions.assertEquals(item1.getId(), 2);
    }

    @Test
    public void testGetName() {
        ReflectionTestUtils.setField(item1, "name", "someName");
        Assertions.assertEquals(item1.getName(), "someName");
        item1.setName("someName2");
        Assertions.assertEquals(item1.getName(), "someName2");
    }

    @Test
    public void testGetCost() {
        ReflectionTestUtils.setField(item1, "cost", 1.2f);
        Assertions.assertEquals(item1.getCost(), 1.2f);
        item1.setCost(1.3f);
        Assertions.assertEquals(item1.getCost(), 1.3f);
    }

    @Test
    public void testGetItemResidue() {
        ReflectionTestUtils.setField(item1, "itemResidue", 12);
        Assertions.assertEquals(item1.getItemResidue(), 12);
        item1.setItemResidue(13);
        Assertions.assertEquals(item1.getItemResidue(), 13);
    }

    @Test
    public void TestToString() {
        ReflectionTestUtils.setField(item1, "id", 1);
        ReflectionTestUtils.setField(item1, "name", "someName");
        ReflectionTestUtils.setField(item1, "cost", 1.0f);
        ReflectionTestUtils.setField(item1, "itemResidue", 1);

        Assertions.assertEquals(ReflectionTestUtils.invokeMethod(item1, "toString"), "Id: 1; Name: someName; cost: 1.0; itemResidue: 1");
    }
}

