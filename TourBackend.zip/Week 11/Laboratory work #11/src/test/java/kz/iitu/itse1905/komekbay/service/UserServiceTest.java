package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.User;
import kz.iitu.itse1905.komekbay.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

class UserServiceTest {
    @Mock
    UserRepository userRepository;
    @InjectMocks
    UserService userService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAll() {
        when(userRepository.findAll()).thenReturn(Arrays.<User>asList(new User(0, "username", "password", "phoneNumber")));

        List<User> result = userService.getAll();
        Assertions.assertNotNull(result);
    }

    @Test
    void testSaveUser() {
        when(userRepository.save(any())).thenReturn(new User(0, "username", "password", "phoneNumber"));

        User result = userService.saveUser(new User(0, "username", "password", "phoneNumber"));
        Assertions.assertNotNull(result);
    }

    @Test
    void testDeleteUserById() {
        userService.deleteUserById(0);
    }

    @Test
    void testGetByIdGreaterThan() {
        when(userRepository.findByIdGreaterThan(anyInt())).thenReturn(Arrays.<User>asList(new User(0, "username", "password", "phoneNumber")));

        List<User> result = userService.getByIdGreaterThan(0);
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetByIdLessThan() {
        when(userRepository.findByIdLessThan(anyInt())).thenReturn(Arrays.<User>asList(new User(0, "username", "password", "phoneNumber")));

        List<User> result = userService.getByIdLessThan(0);
        Assertions.assertNotNull(result);
    }

    @Test
    void testFindUserByID() {
        when(userRepository.findUserById(anyInt())).thenReturn(new User(0, "username", "password", "phoneNumber"));

        User result = userService.findUserByID(0);
        Assertions.assertNotNull(result);
    }
}
