package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Order;
import kz.iitu.itse1905.komekbay.repository.OrderRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class OrderServiceTest {
    @Mock
    OrderRepository orderRepository;
    @InjectMocks
    OrderService orderService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAll() {
        when(orderRepository.findAll()).thenReturn(Arrays.<Order>asList(new Order(0, 0, true, 0)));

        List<Order> result = orderService.getAll();
        Assertions.assertNotNull(result);
    }

    @Test
    void testSaveOrder() {
        when(orderRepository.save(any())).thenReturn(new Order(0, 0, true, 0));

        Order result = orderService.saveOrder(new Order(0, 0, true, 0));
        Assertions.assertNotNull(result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme