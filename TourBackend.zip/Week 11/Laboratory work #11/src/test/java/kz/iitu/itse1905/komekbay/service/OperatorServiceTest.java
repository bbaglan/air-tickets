package kz.iitu.itse1905.komekbay.service;

import kz.iitu.itse1905.komekbay.database.Operator;
import kz.iitu.itse1905.komekbay.repository.OperatorRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

class OperatorServiceTest {
    @Mock
    OperatorRepository operatorRepository;
    @InjectMocks
    OperatorService operatorService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAll() {
        when(operatorRepository.findAll()).thenReturn(Arrays.<Operator>asList(new Operator(0, "login", "password")));

        List<Operator> result = operatorService.getAll();
        Assertions.assertNotNull(result);
    }

    @Test
    void testSaveOper() {
        when(operatorRepository.save(any())).thenReturn(new Operator(0, "login", "password"));

        Operator result = operatorService.saveOper(new Operator(0, "login", "password"));
        Assertions.assertNotNull(result);
    }

    @Test
    void testDeleteOperatorById() {
        operatorService.deleteOperatorById(0);
    }

    @Test
    void testGetByLoginLike() {
        when(operatorRepository.findByLoginLike(anyString())).thenReturn(new Operator(0, "login", "password"));

        Operator result = operatorService.getByLoginLike("login");
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetByLoginNotLike() {
        when(operatorRepository.findByLoginNotLike(anyString())).thenReturn(Arrays.<Operator>asList(new Operator(0, "login", "password")));

        List<Operator> result = operatorService.getByLoginNotLike("login");
        Assertions.assertNotNull(result);
    }
}