package kz.iitu.itse1905.komekbay.Configuration;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.jms.support.converter.MessageConverter;

class JMSConfigTest {
    JMSConfig jMSConfig = new JMSConfig();


    @Test
    void testJacksonJmsMessageConverter() {
        MessageConverter result = jMSConfig.jacksonJmsMessageConverter();
        Assertions.assertNotNull(result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme