package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Operator;
import kz.iitu.itse1905.komekbay.service.OperatorService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

class OperatorControllerTest {
    @Mock
    OperatorService operatorService;
    @InjectMocks
    OperatorController operatorController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testGetAllOperator() {
        when(operatorService.getAll()).thenReturn(Arrays.<Operator>asList(new Operator(0, "login", "password")));

        ResponseEntity<List<Operator>> result = operatorController.getAllOperator();
        Assertions.assertNotNull(result);
    }

    @Test
    void testCreate() {
        when(operatorService.saveOper(any())).thenReturn(new Operator(0, "login", "password"));

        ResponseEntity<Operator> result = operatorController.create(new Operator(0, "login", "password"));
        Assertions.assertNotNull(result);
    }

    @Test
    void testUpdate() {
        when(operatorService.saveOper(any())).thenReturn(new Operator(0, "login", "password"));

        operatorController.update(new Operator(0, "login", "password"), 0);
    }

    @Test
    void testDeleteOperatorById() {
        ResponseEntity<Void> result = operatorController.deleteOperatorById(0);
        Assertions.assertNotNull(result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme