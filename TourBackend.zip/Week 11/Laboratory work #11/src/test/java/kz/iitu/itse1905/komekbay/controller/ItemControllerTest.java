package kz.iitu.itse1905.komekbay.controller;

import kz.iitu.itse1905.komekbay.database.Item;
import kz.iitu.itse1905.komekbay.service.ItemService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

class ItemControllerTest {
    @Mock
    ItemService itemService;
    @InjectMocks
    ItemController itemController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    void testFindHeadItem() {
        when(itemService.getAll()).thenReturn(Arrays.<Item>asList(new Item(0, "name", 0f, 0)));

        ResponseEntity<List<Item>> result = itemController.findHeadItem();
        Assertions.assertNotNull(result);
    }

    @Test
    void testCollectionOptionsItem() {
        ResponseEntity<?> result = itemController.collectionOptionsItem();
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetAllItem() {
        when(itemService.getAll()).thenReturn(Arrays.<Item>asList(new Item(0, "name", 0f, 0)));

        ResponseEntity<List<Item>> result = itemController.getAllItem();
        Assertions.assertNotNull(result);
    }

    @Test
    void testGetAllItemWithPaging() {
        when(itemService.getAllWithPaging(anyInt(), anyInt())).thenReturn(Arrays.<Item>asList(new Item(0, "name", 0f, 0)));

        ResponseEntity<List<Item>> result = itemController.getAllItemWithPaging(0, 0);
        Assertions.assertNotNull(result);
    }

    @Test
    void testCreate() {
        when(itemService.saveItem(any())).thenReturn(new Item(0, "name", 0f, 0));

        ResponseEntity<Item> result = itemController.create(new Item(0, "name", 0f, 0));
        Assertions.assertNotNull(result);
    }

    @Test
    void testUpdate() {
        when(itemService.saveItem(any())).thenReturn(new Item(0, "name", 0f, 0));

        itemController.update(new Item(0, "name", 0f, 0), 0);
    }

    @Test
    void testDeleteItemById() {
        ResponseEntity<Void> result = itemController.deleteItemById(0);
        Assertions.assertNotNull(result);
    }
}