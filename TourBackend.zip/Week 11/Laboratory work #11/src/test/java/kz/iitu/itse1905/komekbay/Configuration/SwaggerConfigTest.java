package kz.iitu.itse1905.komekbay.Configuration;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import springfox.documentation.spring.web.plugins.Docket;

class SwaggerConfigTest {
    SwaggerConfig swaggerConfig = new SwaggerConfig();

    @Test
    void testSwaggerConfiguration() {
        Docket result = swaggerConfig.swaggerConfiguration();
        Assertions.assertNotNull(result);
    }
}

