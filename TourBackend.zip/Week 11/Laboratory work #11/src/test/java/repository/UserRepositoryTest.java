package repository;

import kz.iitu.itse1905.komekbay.KomekbayApplication;
import kz.iitu.itse1905.komekbay.database.User;
import kz.iitu.itse1905.komekbay.repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@DataJpaTest
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { KomekbayApplication.class })
@WebAppConfiguration
class UserRepositoryTest {
    @Autowired
    UserRepository userRepository;

    @Test
    public void testFindAll() {
        List<User> userList  = userRepository.findAll();
        Assertions.assertNotNull(userList);
    }

    @Test
    public void save(){
        User user1 = new User(1,"Friends","somePass","8702");
        User result = userRepository.save(user1);
        Assertions.assertNotNull(result);
    }

    @Test
    public void delete(){
        User user1 = new User(1,"Friends","somePass","8702");

        userRepository.delete(user1);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme