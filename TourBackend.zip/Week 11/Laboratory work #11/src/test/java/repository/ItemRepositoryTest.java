package repository;

import kz.iitu.itse1905.komekbay.KomekbayApplication;
import kz.iitu.itse1905.komekbay.database.Item;
import kz.iitu.itse1905.komekbay.repository.ItemRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@DataJpaTest
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { KomekbayApplication.class })
@WebAppConfiguration
class ItemRepositoryTest {
    @Autowired
    ItemRepository itemRepository;

    @Test
    public void testFindAll() {
        List<Item> itemList  = itemRepository.findAll();
        Assertions.assertNotNull(itemList);
    }

    @Test
    public void save(){
        Item item1 = new Item(1,"Friends",1.2f,10);
        Item result = itemRepository.save(item1);
        Assertions.assertNotNull(result);
    }

    @Test
    public void delete(){
        Item item1 = new Item(1,"Friends",1.2f,10);

        itemRepository.delete(item1);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme