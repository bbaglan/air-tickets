package repository;

import kz.iitu.itse1905.komekbay.KomekbayApplication;
import kz.iitu.itse1905.komekbay.database.Operator;
import kz.iitu.itse1905.komekbay.repository.OperatorRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@DataJpaTest
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { KomekbayApplication.class })
@WebAppConfiguration
class OperatorRepositoryTest {
    @Autowired
    OperatorRepository operatorRepository;

    @Test
    public void testFindAll() {
        List<Operator> operList  = operatorRepository.findAll();
        Assertions.assertNotNull(operList);
    }

    @Test
    public void save(){
        Operator oper1 = new Operator(1,"Friends","somePass");
        Operator result = operatorRepository.save(oper1);
        Assertions.assertNotNull(result);
    }

    @Test
    public void delete(){
        Operator oper1 = new Operator(1,"Friends","somePass");

        operatorRepository.delete(oper1);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme