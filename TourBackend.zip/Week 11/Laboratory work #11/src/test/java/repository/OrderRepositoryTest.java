package repository;

import kz.iitu.itse1905.komekbay.KomekbayApplication;
import kz.iitu.itse1905.komekbay.database.Order;
import kz.iitu.itse1905.komekbay.repository.OrderRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import java.util.List;

@DataJpaTest
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = { KomekbayApplication.class })
@WebAppConfiguration
class OrderRepositoryTest {
    @Autowired
    OrderRepository orderRepository;

    @Test
    public void testFindAll() {
        List<Order> orderList  = orderRepository.findAll();
        Assertions.assertNotNull(orderList);
    }

    @Test
    public void save(){
        Order order1 = new Order(1,2,false,2);
        Order result = orderRepository.save(order1);
        Assertions.assertNotNull(result);
    }
}

//Generated with love by TestMe :) Please report issues and submit feature requests at: http://weirddev.com/forum#!/testme